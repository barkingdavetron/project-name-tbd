describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://localhost:3000/login')
    cy.get('input#email').type('johndoe@gmail.com')
    cy.get('input#firstName').type('john')
    cy.get('input#lastName').type('doe')
    cy.get('input#username').type('johnnydoe')
    cy.get('input#password').type('password')
    cy.get('form').submit()
  })
})