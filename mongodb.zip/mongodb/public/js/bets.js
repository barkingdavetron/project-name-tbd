// bets.js

const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
const options = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a',
        'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
    }
};

let events = [];
let betHistory = [];

async function fetchData() {
    try {
        const response = await fetch(url, options);
        const result = await response.json();
        console.log(result);
        events = result;
        displayEvents(events);
        document.getElementById('betting-form').style.display = 'block';
    } catch (error) {
        console.error(error);
        document.getElementById('results').innerHTML = `<p>Error: ${error.message}</p>`;
    }
}

function displayEvents(events) {
    const eventSelect = document.getElementById('event-select');
    eventSelect.innerHTML = '';
    events.forEach((event, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = `${event.home_team} vs ${event.away_team}`;
        eventSelect.appendChild(option);
    });
    updateOutcomes();
}

function updateOutcomes() {
    const eventSelect = document.getElementById('event-select');
    const selectedEventIndex = eventSelect.value;
    const selectedEvent = events[selectedEventIndex];
    const outcomeSelect = document.getElementById('outcome-select');
    outcomeSelect.innerHTML = '';

    if (selectedEvent && selectedEvent.bookmakers && selectedEvent.bookmakers.length > 0) {
        const outcomes = selectedEvent.bookmakers[0].markets[0].outcomes; // Assuming first bookmaker and first market
        outcomes.forEach((outcome, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = `${outcome.name} (Odds: ${outcome.price})`;
            outcomeSelect.appendChild(option);
        });
    }
}

function placeBet() {
    const eventSelect = document.getElementById('event-select');
    const selectedEventIndex = eventSelect.value;
    const outcomeSelect = document.getElementById('outcome-select');
    const selectedOutcomeIndex = outcomeSelect.value;
    const betAmount = parseFloat(document.getElementById('bet-amount').value);
    const selectedEvent = events[selectedEventIndex];
    const selectedOutcome = selectedEvent.bookmakers[0].markets[0].outcomes[selectedOutcomeIndex]; // Assuming first bookmaker and first market
    const potentialPayout = betAmount * selectedOutcome.price;

    const bet = {
        event: `${selectedEvent.home_team} vs ${selectedEvent.away_team}`,
        outcome: selectedOutcome.name,
        amount: betAmount,
        payout: potentialPayout
    };

    betHistory.push(bet);
    displayBetHistory();

    document.getElementById('bet-result').innerHTML = `
        <p>You placed a bet of $${betAmount.toFixed(2)} on ${selectedOutcome.name} in ${selectedEvent.home_team} vs ${selectedEvent.away_team}.</p>
        <p>Potential Payout: $${potentialPayout.toFixed(2)}</p>
    `;
}

function deleteBet(index) {
    betHistory.splice(index, 1);
    displayBetHistory();
}

function displayBetHistory() {
    const betHistoryDiv = document.getElementById('bet-history');
    const betTableBody = document.getElementById('bet-table').getElementsByTagName('tbody')[0];
    betTableBody.innerHTML = '';

    betHistory.forEach((bet, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${bet.event}</td>
            <td>${bet.outcome}</td>
            <td>$${bet.amount.toFixed(2)}</td>
            <td>$${bet.payout.toFixed(2)}</td>
            <td><button class="delete-button" onclick="deleteBet(${index})">Delete</button></td>
        `;
        betTableBody.appendChild(row);
    });

    betHistoryDiv.style.display = betHistory.length ? 'block' : 'none';
}

document.getElementById('event-select').addEventListener('change', updateOutcomes);

fetchData();
