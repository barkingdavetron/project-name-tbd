-- Create sequence for users table primary key
CREATE SEQUENCE IF NOT EXISTS users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

-- Create users table
CREATE TABLE IF NOT EXISTS public.users
(
    id integer NOT NULL DEFAULT nextval('users_id_seq'::regclass),
    first_name character varying(50) COLLATE pg_catalog."default",
    last_name character varying(50) COLLATE pg_catalog."default",
    email character varying(100) COLLATE pg_catalog."default" NOT NULL,
    password character varying(255) COLLATE pg_catalog."default" NOT NULL,
    username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    balance numeric DEFAULT 0,
    CONSTRAINT users_pkey PRIMARY KEY (id),
    CONSTRAINT users_email_key UNIQUE (email),
    CONSTRAINT users_username_key UNIQUE (username)
)
TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.users
    OWNER to admin;

-- Create sequence for bets table primary key
CREATE SEQUENCE IF NOT EXISTS bets_bet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

-- Create bets table
CREATE TABLE IF NOT EXISTS public.bets
(
    id integer NOT NULL DEFAULT nextval('bets_bet_id_seq'::regclass),
    user_id integer NOT NULL,
    bet_details text COLLATE pg_catalog."default",
    amount numeric(10,2),
    odds numeric(5,2),
    status character varying(20) COLLATE pg_catalog."default",
    placed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    payout numeric,
    event character varying COLLATE pg_catalog."default",
    outcome character varying COLLATE pg_catalog."default",
    processed boolean DEFAULT false,
    won boolean DEFAULT false,
    CONSTRAINT bets_pkey PRIMARY KEY (id),
    CONSTRAINT bets_user_id_fkey FOREIGN KEY (user_id)
        REFERENCES public.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.bets
    OWNER to admin;