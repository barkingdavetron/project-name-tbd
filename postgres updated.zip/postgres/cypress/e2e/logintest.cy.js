describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://localhost:3000/login')
    cy.get('input#email').type('johndoe@gmail.com')
    cy.get('input#password').type('password')
    cy.get('form').submit()
  })
})