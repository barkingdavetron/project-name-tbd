let footballquestions = [
    {
        numb:1,
        question:"What English Premier League team did Cristiano Ronaldo play two seperate times for?",
        answer:"C. Manchester United",
        options:[
            "A. Arsenal",
            "B. Liverpool",
            "C. Manchester United",
            "D. Chelsea"
        ]
    },
    {
        numb:2,
        question:"What international Football tournament takes place in between European countries",
        answer:"C. The European Championship ",
        options:[
            "A. The Copa America ",
            "B. The World Cup ",
            "C. The European Championship ",
            "D. The African Cup of Nations"
        
        ]
    },
    {
        numb:3,
        question:"Who is the current champions of the World?",
        answer:"A. Argentina",
        options:[
            "A. Argentina",
            "B. Brazil",
            "C. Ireland",
            "D. England"

        ]
    },
    {
        numb:4,
        question:"What is the name of the national league in Spain?",
        answer:"D. La Liga",
        options:[
            "A. Bundesliga",
            "B. Premier League",
            "C. Airtricity League",
            "D. La Liga"

        ]
    },
    {
        numb:5,
        question:"Which team has won the Champions League the most amount of times?? ",
        answer:"B. Real Madrid",
        options:[
            "A. Shamrock Rovers",
            "B. Real Madrid",
            "C. Liverpool",
            "D. Celtic"

        ]
    }
];

let f1questions = [ 
    {
        numb:1,
        question:"What driver won a historic 6 world championships in a row?",
        answer:"C. Lewis Hamilton",
        options:[
            "A. Charles Leclerc",
            "B. Lando Norris",
            "C. Lewis Hamilton",
            "D. Pierre Gasly "
        ]
    },
    {
        numb:2,
        question:"Which constructor has won the most amount of world championships?",
        answer:"D. Ferrari",
        options:[
            "A. Stake F1 Team",
            "B. Red Bull",
            "C. Mclaren",
            "D. Ferrari"
        
        ]
    },
    {
        numb:3,
        question:"Which of these tracks is among the oldest on the F1 calender:",
        answer:"A. Monacco",
        options:[
            "A. Monacco",
            "B. China",
            "C. Abu Dhabi",
            "D. Bahrain"

        ]
    },
    {
        numb:4,
        question:"Which reserve driver is the son of the famous Michael Schumacher?",
        answer:"A. Mick",
        options:[
            "A. Mick",
            "B. Toto",
            "C. Danny",
            "D. Lewis"

        ]
    },
    {
        numb:5,
        question:"How many races are on this seasons F1 calender?",
        answer:"D. 24",
        options:[
            "A. 8",
            "B. 30",
            "C. 13",
            "D. 24"

        ]
    }
];

let mmaquestions = [ 
    {
        numb:1,
        question:"Who is the highest earning Irish MMA fighter of all time?",
        answer:"A. Conor McGregor",
        options:[
            "A. Conor McGregor",
            "B. Nate Diaz",
            "C. Gary Cully",
            "D. Johnny Walker "
        ]
    },
    {
        numb:2,
        question:"Who is the head promoter of the UFC?",
        answer:"D. Dana White",
        options:[
            "A. Eddie Hearn",
            "B. Toto Wolf",
            "C. Paul Haymen",
            "D. Dana White"
        
        ]
    },
    {
        numb:3,
        question:"Who is the current champion of the UFC heavyweight division?",
        answer:"A. Jon Jones",
        options:[
            "A. Jon Jones",
            "B. Alex Periera",
            "C. Conor McGregor",
            "D. Anthony Joshua"

        ]
    },
    {
        numb:4,
        question:"As of the beginning of July 2024, what UFC are we on?",
        answer:"B. 304",
        options:[
            "A. 121",
            "B. 304",
            "C. 496",
            "D. 275"

        ]
    },
    {
        numb:5,
        question:"How many primary weight classes are there in the UFC?",
        answer:"D. 8",
        options:[
            "A. 3",
            "B. 30",
            "C. 13",
            "D. 8"

        ]
    }
];
