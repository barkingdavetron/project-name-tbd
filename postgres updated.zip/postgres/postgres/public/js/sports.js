document.addEventListener('DOMContentLoaded', () => {
    let questionCount = 0;
    let questionNumb = 1;
    let userScore = 0;
    let userXP = 0;
    let userLevel = 1;

    const nextBtn = document.querySelector('.next-btn');
    const startBtn = document.querySelector('.start-btn');
    const popupInfo = document.querySelector('.popup-info');
    const exitBtn = document.querySelector('.exit-btn');
    const continueBtn = document.querySelector('.continue-btn');
    const quizSection = document.querySelector('.quiz-section');
    const quizBox = document.querySelector('.quiz-box');
    const resultBox = document.querySelector('.result-box');
    const tryAgainBtn = document.querySelector('.tryAgain-btn');
    const goHomeBtn = document.querySelector('.goHome-btn');
    const optionList = document.querySelector('.option-list');

    // Event Listeners
    startBtn.onclick = () => popupInfo.classList.add('active');
    exitBtn.onclick = () => popupInfo.classList.remove('active');
    continueBtn.onclick = startQuiz;
    tryAgainBtn.onclick = resetQuiz;
    goHomeBtn.onclick = resetQuiz;

    nextBtn.onclick = () => {
        if (questionCount < footballquestions.length - 1) {
            questionCount++;
            questionNumb++;
            showQuestions(questionCount);
            questionCounter(questionNumb);
            nextBtn.classList.remove('active');
        } else {
            userXP += userScore; // Add user score to XP
            updateExperienceBar();
            showResultBox();
        }
    };

    // Functions
    function startQuiz() {
        quizSection.classList.add('active');
        popupInfo.classList.remove('active');
        quizBox.classList.add('active');
        showQuestions(0);
        questionCounter(1);
        headerScore(0);
    }

    function resetQuiz() {
        quizBox.classList.add('active');
        nextBtn.classList.remove('active');
        resultBox.classList.remove('active');
        questionCount = 0;
        questionNumb = 1;
        userScore = 0;
        showQuestions(questionCount);
        questionCounter(questionNumb);
        headerScore();
    }

    function showQuestions(index) {
        const questionText = document.querySelector('.question-text');
        if (questionText) {
            questionText.textContent = `${footballquestions[index].numb}. ${footballquestions[index].question}`;
            let optionTag = footballquestions[index].options.map(option => `<div class="option"><span>${option}</span></div>`).join('');
            optionList.innerHTML = optionTag;
            const options = document.querySelectorAll('.option');
            options.forEach(option => option.addEventListener('click', () => optionSelected(option)));
        }
    }

    function optionSelected(answer) {
        let userAnswer = answer.textContent;
        let correctAnswer = footballquestions[questionCount].answer;
        let allOptions = optionList.children.length;
        if (userAnswer == correctAnswer) {
            answer.classList.add('correct');
            userScore += 1;
            headerScore();
        } else {
            answer.classList.add('incorrect');
            for (let i = 0; i < allOptions; i++) {
                if (optionList.children[i].textContent == correctAnswer) {
                    optionList.children[i].setAttribute('class', 'option correct');
                }
            }
        }
        for (let i = 0; i < allOptions; i++) {
            optionList.children[i].classList.add('disabled');
        }
        nextBtn.classList.add('active');
    }

    function questionCounter(index) {
        const questionTotal = document.querySelector('.question-total');
        if (questionTotal) {
            questionTotal.textContent = `${index} of ${footballquestions.length} Questions`;
        }
    }

    function headerScore() {
        const headerScoreText = document.querySelector('.header-score');
        if (headerScoreText) {
            headerScoreText.textContent = `Score: ${userScore} / ${footballquestions.length}`;
        }
    }

    function showResultBox() {
        const quizBox = document.querySelector('.quiz-box');
        const resultBox = document.querySelector('.result-box');
        if (quizBox && resultBox) {
            quizBox.classList.remove('active');
            resultBox.classList.add('active');
            const scoreText = document.querySelector('.score-text');
            if (scoreText) {
                scoreText.textContent = `Your Score ${userScore} out of ${footballquestions.length}`;
            }
            updateCircularProgress();
        }
    }

    function updateCircularProgress() {
        const circularProgress = document.querySelector('.circular-progress');
        const progressValue = document.querySelector('.progress-value');
        let progressStartValue = 0;
        let progressEndValue = Math.min((userScore / footballquestions.length) * 100, 100);
        let speed = 20;
        let progress = setInterval(() => {
            progressStartValue++;
            if (progressStartValue > progressEndValue) {
                progressStartValue = progressEndValue;
                clearInterval(progress);
            }
            if (progressValue) {
                progressValue.textContent = `${progressStartValue}%`;
            }
            if (circularProgress) {
                circularProgress.style.background = `conic-gradient(#ff9900 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
            }
        }, speed);
    }

    function updateExperienceBar() {
        const experienceBar = document.getElementById('experience-bar');
        const experienceText = document.getElementById('experience-text');
        if (experienceBar && experienceText) {
            experienceBar.style.width = `${(userXP % 10) * 10}%`;
            experienceText.textContent = `${userXP % 10}/10 XP`;
            if (userXP >= 10) {
                userLevel += Math.floor(userXP / 10);
                userXP = userXP % 10;
                alert(`Congratulations! You've reached level ${userLevel}`);
                updateLevelDisplay();
            }
        } else {
            console.error('Experience bar or level element not found in the DOM.');
        }
    }

    function updateLevelDisplay() {
        const userLevelElement = document.querySelector('.user-level');
        if (userLevelElement) {
            userLevelElement.textContent = `Level: ${userLevel}`;
        }
    }

    function fetchUserData() {
        fetch('/userData')
            .then(response => response.json())
            .then(data => {
                if (data.experience_points !== undefined && data.level !== undefined) {
                    userXP = data.experience_points;
                    userLevel = data.level;
                    updateExperienceBar();
                }
            })
            .catch(error => console.error('Error fetching user data:', error));
    }

    fetchUserData();
});
