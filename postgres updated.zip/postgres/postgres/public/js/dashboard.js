document.addEventListener('DOMContentLoaded', (event) => {
    console.log('Dashboard loaded');
    // Additional JavaScript functionality can be added here
});
