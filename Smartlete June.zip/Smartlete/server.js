const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files from the 'public' directory

// In-memory storage for bets
let bets = [];

// Endpoint to get all bets
app.get('/api/bets', (req, res) => {
    res.json(bets);
});

// Endpoint to place a bet
app.post('/api/bets', (req, res) => {
    const { match, betType, amount, odds } = req.body;
    const newBet = { id: bets.length + 1, match, betType, amount, odds };
    bets.push(newBet);
    res.status(201).json(newBet);
});

// Endpoint to delete a bet
app.delete('/api/bets/:id', (req, res) => {
    const { id } = req.params;
    bets = bets.filter(bet => bet.id !== parseInt(id));
    res.status(204).end();
});

// Serve the index.html for any unknown routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
