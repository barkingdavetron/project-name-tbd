const express = require('express');
const axios = require('axios');

const router = express.Router();

// Route to fetch matches from the external API
router.get('/matches', async (req, res) => {
    try {
        const url = 'https://pinnacle-odds.p.rapidapi.com/kit/v1/special-markets?sport_id=1&is_have_odds=true';
        const options = {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a',
                'X-RapidAPI-Host': 'pinnacle-odds.p.rapidapi.com'
            }
        };

        const response = await axios(url, options);
        const oddsData = response.data.specials;

        // Return the fetched data as the response
        res.json(oddsData);
    } catch (error) {
        console.error('Error fetching odds:', error);
        res.status(500).send('Error fetching odds');
    }
});

module.exports = router;
