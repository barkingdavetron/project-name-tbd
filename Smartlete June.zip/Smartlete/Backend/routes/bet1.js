const express = require('express');
const router = express.Router();
const Bet = require('../models/Bet');

// Route to place a new bet
router.post('/bets', async (req, res) => {
    try {
        const { userId, matchId, betType, betAmount, potentialPayout } = req.body;
        const newBet = new Bet({
            userId,
            matchId,
            betType,
            betAmount,
            potentialPayout,
            status: 'pending'
        });
        const savedBet = await newBet.save();
        res.json(savedBet);
    } catch (err) {
        res.status(500).json({ error: 'Failed to place bet' });
    }
});

// Route to get all bets
router.get('/bets', async (req, res) => {
    try {
        const bets = await Bet.find();
        res.json(bets);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch bets' });
    }
});

// Route to get a specific bet by ID
router.get('/bets/:id', async (req, res) => {
    try {
        const bet = await Bet.findById(req.params.id);
        res.json(bet);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch bet' });
    }
});

// Route to update a bet
router.put('/bets/:id', async (req, res) => {
    try {
        const updatedBet = await Bet.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedBet);
    } catch (err) {
        res.status(500).json({ error: 'Failed to update bet' });
    }
});

// Route to delete a bet
router.delete('/bets/:id', async (req, res) => {
    try {
        await Bet.findByIdAndDelete(req.params.id);
        res.json({ message: 'Bet deleted' });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete bet' });
    }
});

module.exports = router;
