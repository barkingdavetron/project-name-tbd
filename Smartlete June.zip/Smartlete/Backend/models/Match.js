const mongoose = require('mongoose');

const MatchSchema = new mongoose.Schema({
    home: {
        type: String,
        required: true
    },
    away: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    odds: {
        homeWin: {
            type: Number,
            required: true
        },
        draw: {
            type: Number,
            required: true
        },
        awayWin: {
            type: Number,
            required: true
        }
    }
});

module.exports = mongoose.model('Match', MatchSchema);
