const url = 'https://betfair14.p.rapidapi.com/api/home';
const options = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a',
        'X-RapidAPI-Host': 'betfair14.p.rapidapi.com'
    }
};

async function fetchData() {
    try {
        const response = await fetch(url, options);
        const result = await response.json();
        console.log("API Data:", result); // Log the entire API response to inspect its structure
        populateDropdown(result);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

function populateDropdown(data) {
    const dropdown = document.getElementById('event-dropdown');
    dropdown.innerHTML = '<option value="">Select an event</option>'; // Reset the dropdown

    data.forEach(sport => {
        sport.markets.forEach(match => {
            const option = document.createElement('option');
            option.value = JSON.stringify({ sport: sport.name, match: match });
            option.textContent = `${sport.name}: ${match.marketName}`;
            dropdown.appendChild(option);
        });
    });
}

function getFirstNonEmptyPrice(prices) {
    for (const priceObj of prices) {
        if (priceObj.price) {
            return priceObj.price;
        }
    }
    return 'N/A';
}

function displayEventDetails() {
    const dropdown = document.getElementById('event-dropdown');
    const selectedValue = dropdown.value;
    const eventDetailsContainer = document.getElementById('event-details');

    if (selectedValue) {
        const { sport, match } = JSON.parse(selectedValue);
        console.log("Selected Match:", match); // Log the selected match object

        let oddsHtml = '';

        if (match.runners) {
            oddsHtml = '<h3>Odds:</h3><ul>';
            match.runners.forEach(runner => {
                console.log("Runner:", runner); // Log the runner object
                const odds = getFirstNonEmptyPrice(runner.back);
                oddsHtml += `<li>${runner.runnerName}: ${odds}</li>`;
            });
            oddsHtml += '</ul>';
        } else {
            oddsHtml = '<p>No odds available.</p>';
        }

        const eventDetails = `
            <h2>${match.marketName}</h2>
            <p>Sport: ${sport}</p>
            <p>Start Time: ${match.marketStartTime}</p>
            <p>Status: ${match.inplay ? 'In Play' : 'Not In Play'}</p>
            <p>Market ID: ${match.marketId}</p>
            ${oddsHtml}
        `;
        eventDetailsContainer.innerHTML = eventDetails;
    } else {
        eventDetailsContainer.innerHTML = '';
    }
}

window.onload = () => {
    fetchData();
    document.getElementById('event-dropdown').addEventListener('change', displayEventDetails);
};
