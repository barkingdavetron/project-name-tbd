let sportsquestions = [
    {
        numb:1,
        question:"What English Premier League team did Cristiano Ronaldo play two seperate times for?",
        answer:"C. Manchester United",
        options:[
            "A. Arsenal",
            "B. Liverpool",
            "C. Manchester United",
            "D. Chelsea"
        ]
    },
    {
        numb:2,
        question:"Who has the current highest number of points scored in NBA history?",
        answer:"C. Lebron James",
        options:[
            "A. Michael Jordan",
            "B. Larry Bird",
            "C. Lebron James",
            "D. Joel Embiid"
        
        ]
    },
    {
        numb:3,
        question:"Who are the current GAA football champions?",
        answer:"A. Dublin",
        options:[
            "A. Dublin",
            "B. Cork",
            "C. Kilkenny",
            "D. Limerick"

        ]
    },
    {
        numb:4,
        question:"Who did Ireland lose to in the 2024 Rugby World Cup?",
        answer:"D. New Zealand",
        options:[
            "A. England",
            "B. France",
            "C. Scotland",
            "D. New Zealand"

        ]
    },
    {
        numb:5,
        question:"What team have won the Liam MacCarty Hurling Cup a record 5 times in a row? ",
        answer:"B. Limerick",
        options:[
            "A. Dublin",
            "B. Limerick",
            "C. Louth",
            "D. Kerry"

        ]
    }
];

let geographyquestions = [ 
    {
        numb:1,
        question:"Which of these are a capital of an African country? ",
        answer:"C. Cairo",
        options:[
            "A. Paris",
            "B. Rabat",
            "C. Cairo",
            "D. London"
        ]
    },
    {
        numb:2,
        question:"What is the largest continent in the world?",
        answer:"D. Asia",
        options:[
            "A. Europe",
            "B. South America",
            "C. Oceania",
            "D. Asia"
        
        ]
    },
    {
        numb:3,
        question:"Which three continents does the equator pass through?",
        answer:"A. Africa, Asia and South America",
        options:[
            "A. Africa, Asia and South America",
            "B. South America, North America, Europe",
            "C. Antartica, North America, Oceania",
            "D. Asia, Europe, North America"

        ]
    },
    {
        numb:4,
        question:"What body of water seperates Ireland from the Unied States?",
        answer:"A. The Atlantic Ocean",
        options:[
            "A. The Atlantic Ocean",
            "B. The Red Sea",
            "C. The Pacific Ocean",
            "D. The Indian Ocean "

        ]
    },
    {
        numb:5,
        question:"What is the largest State in America? ",
        answer:"D. Texas",
        options:[
            "A. Idaho",
            "B. New York",
            "C. New Mexico",
            "D. Texas"

        ]
    }
];
