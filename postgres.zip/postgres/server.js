const express = require('express');
const session = require('express-session');
const { Pool } = require('pg');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const fetch = require('node-fetch');
const cron = require('node-cron');

const app = express();
app.use(express.json());

// Configure PostgreSQL connection
const pool = new Pool({
    user: 'admin',
    host: 'db',
    database: 'users',
    password: 'admin',
    port: 5432,
});

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Generate a secure random secret key
const secretKey = crypto.randomBytes(32).toString('hex');

// Configure session middleware
app.use(session({
    secret: secretKey,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Middleware to log session data
app.use((req, res, next) => {
    console.log('Session:', req.session);
    next();
});

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to protect routes
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    } else {
        res.redirect('/login');
    }
}

// Render registration form
app.get('/', (req, res) => {
    res.render('index');
});

// Handle registration
app.post('/register', async (req, res) => {
    const { firstName, lastName, email, password, username } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password with bcryptjs
        const query = 'INSERT INTO users (first_name, last_name, email, password, username, balance) VALUES ($1, $2, $3, $4, $5, $6)';
        const values = [firstName, lastName, email, hashedPassword, username, 0];
        await pool.query(query, values);
        res.redirect('/login');
    } catch (err) {
        console.error('Error inserting user data:', err);
        res.status(500).send('Error inserting user data');
    }
});

// Render login form
app.get('/login', (req, res) => {
    res.render('login');
});

// Handle login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const query = 'SELECT * FROM users WHERE email = $1';
        const values = [email];
        const result = await pool.query(query, values);

        if (result.rows.length > 0) {
            const user = result.rows[0];
            const isPasswordValid = await bcrypt.compare(password, user.password); // Compare the hashed password
            
            if (isPasswordValid) {
                // Save user info in session
                req.session.user = {
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    balance: user.balance
                };
                res.redirect('/dashboard');
            } else {
                res.status(401).send('Invalid email or password');
            }
        } else {
            res.status(401).send('Invalid email or password');
        }
    } catch (err) {
        console.error('Error logging in:', err);
        res.status(500).send('Error logging in');
    }
});

// Protected route (dashboard)
app.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { username: req.session.user.username, balance: req.session.user.balance });
});

// Betting page
app.get('/bets', isAuthenticated, (req, res) => {
    res.render('bets', { username: req.session.user.username });
});

// Account page
app.get('/account', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const betsQuery = 'SELECT * FROM bets WHERE user_id = $1';
        const betsResult = await pool.query(betsQuery, [userId]);
        const bets = betsResult.rows;

        const balanceQuery = 'SELECT balance FROM users WHERE id = $1';
        const balanceResult = await pool.query(balanceQuery, [userId]);
        const balance = balanceResult.rows[0].balance;

        res.render('account', { username: req.session.user.username, balance, bets });
    } catch (error) {
        console.error('Error fetching account data:', error);
        res.status(500).send('Error fetching account data');
    }
});

// Update balance
app.post('/addFunds', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const updateBalanceQuery = 'UPDATE users SET balance = balance + 100 WHERE id = $1';
        await pool.query(updateBalanceQuery, [userId]);

        // Update session balance
        req.session.user.balance += 100;

        res.redirect('/account');
    } catch (error) {
        console.error('Error adding funds:', error);
        res.status(500).send('Error adding funds');
    }
});

// Endpoint to fetch events from Pinnacle API
app.get('/fetchEvents', async (req, res) => {
    try {
        const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
        const options = {
            headers: {
                'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a', // Replace with your actual API key
                'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
            }
        };

        const response = await fetch(url, options);
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Endpoint to place a bet
app.post('/placeBet', async (req, res) => {
    const { event, outcome, amount, payout } = req.body;
    const userId = req.session.user.id;

    try {
        // Check if user has sufficient balance
        const balanceQuery = 'SELECT balance FROM users WHERE id = $1';
        const balanceResult = await pool.query(balanceQuery, [userId]);
        const balance = balanceResult.rows[0].balance;

        if (balance < amount) {
            return res.status(400).json({ error: 'Insufficient balance' });
        }

        // Deduct bet amount from user's balance
        const deductBalanceQuery = 'UPDATE users SET balance = balance - $1 WHERE id = $2';
        await pool.query(deductBalanceQuery, [amount, userId]);

        // Insert bet into database
        const query = 'INSERT INTO bets (user_id, event, outcome, amount, payout, processed) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id';
        const values = [userId, event, outcome, amount, payout, false];
        const result = await pool.query(query, values);

        if (result.rowCount > 0) {
            const betId = result.rows[0].id;
            console.log(`Bet placed successfully with ID ${betId}`);
            res.status(200).json({ message: 'Bet placed successfully' });
        } else {
            console.error('Failed to insert bet into database');
            res.status(500).json({ error: 'Failed to place bet' });
        }
    } catch (error) {
        console.error('Error placing bet:', error);
        res.status(500).json({ error: 'Failed to place bet' });
    }
});

// Function to fetch event results from Pinnacle API
async function fetchEventResults() {
    const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
    const options = {
        headers: {
            'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a', // Replace with your actual API key
            'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
        }
    };

    const response = await fetch(url, options);
    const data = await response.json();

    // Filter only completed events
    const completedEvents = data.filter(event => event.status === 'completed');
    return completedEvents;
}

// Function to process payouts
async function processPayouts() {
    try {
        const selectBetsQuery = 'SELECT * FROM bets WHERE processed = false';
        const betsResult = await pool.query(selectBetsQuery);
        const bets = betsResult.rows;

        const eventResults = await fetchEventResults();

        for (const bet of bets) {
            const { id, user_id, event, outcome, payout } = bet;
            const eventResult = eventResults.find(e => `${e.home_team} vs ${e.away_team}` === event);

            if (eventResult) {
                const isWin = eventResult.winning_outcome === outcome;

                if (isWin) {
                    const updateBalanceQuery = 'UPDATE users SET balance = balance + $1 WHERE id = $2';
                    await pool.query(updateBalanceQuery, [payout, user_id]);
                }

                const updateBetQuery = 'UPDATE bets SET processed = true, won = $1 WHERE id = $2';
                await pool.query(updateBetQuery, [isWin, id]);
            } else {
                console.warn(`No result found for event: ${event}`);
            }
        }
        console.log('Payouts processed successfully');
    } catch (error) {
        console.error('Error processing payouts:', error);
    }
}

// Schedule the payout processing to run every minute
cron.schedule('* * * * *', processPayouts);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
