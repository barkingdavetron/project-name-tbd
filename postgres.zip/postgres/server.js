const express = require('express');
const session = require('express-session');
const { Pool } = require('pg');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());

// Configure PostgreSQL connection
const pool = new Pool({
    user: 'admin',
    host: 'db',
    database: 'users',
    password: 'admin',
    port: 5432,
});

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Generate a secure random secret key
const secretKey = crypto.randomBytes(32).toString('hex');

// Configure session middleware
app.use(session({
    secret: secretKey,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Middleware to log session data
app.use((req, res, next) => {
    console.log('Session:', req.session);
    next();
});

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to protect routes
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    } else {
        res.redirect('/login');
    }
}

// Render registration form
app.get('/', (req, res) => {
    res.render('index');
});

// Handle registration
app.post('/register', async (req, res) => {
    const { firstName, lastName, email, password, username } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password with bcryptjs
        const query = 'INSERT INTO users (first_name, last_name, email, password, username) VALUES ($1, $2, $3, $4, $5)';
        const values = [firstName, lastName, email, hashedPassword, username];
        await pool.query(query, values);
        res.redirect('/login');
    } catch (err) {
        console.error('Error inserting user data:', err);
        res.status(500).send('Error inserting user data');
    }
});

// Render login form
app.get('/login', (req, res) => {
    res.render('login');
});

// Handle login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const query = 'SELECT * FROM users WHERE email = $1';
        const values = [email];
        const result = await pool.query(query, values);

        if (result.rows.length > 0) {
            const user = result.rows[0];
            const isPasswordValid = await bcrypt.compare(password, user.password); // Compare the hashed password
            
            if (isPasswordValid) {
                // Save user info in session
                req.session.user = {
                    id: user.id,
                    email: user.email,
                    username: user.username
                };
                res.redirect('/dashboard');
            } else {
                res.status(401).send('Invalid email or password');
            }
        } else {
            res.status(401).send('Invalid email or password');
        }
    } catch (err) {
        console.error('Error logging in:', err);
        res.status(500).send('Error logging in');
    }
});

// Protected route (dashboard)
app.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { username: req.session.user.username });
});

// Betting page
app.get('/bets', isAuthenticated, (req, res) => {
    res.render('bets', { username: req.session.user.username });
});

// Endpoint to fetch events from Pinnacle API
app.get('/fetchEvents', async (req, res) => {
    try {
        const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
        const options = {
            headers: {
                'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a', // Replace with your actual API key
                'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
            }
        };

        const response = await fetch(url, options);
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Endpoint to place a bet
app.post('/placeBet', async (req, res) => {
    console.log('Received data:', req.body); // Log the received data

    const { event, outcome, amount, payout } = req.body;
    const userId = req.session.user.id;

    console.log('Event:', event);
    console.log('Outcome:', outcome);
    console.log('Amount:', amount);
    console.log('Payout:', payout);
    console.log('User ID:', userId);

    try {
        const query = 'INSERT INTO bets (user_id, event, outcome, amount, payout) VALUES ($1, $2, $3, $4, $5) RETURNING id';
        const values = [userId, event, outcome, amount, payout];
        const result = await pool.query(query, values);

        if (result.rowCount > 0) {
            const betId = result.rows[0].id;
            console.log(`Bet placed successfully with ID ${betId}`);
            res.status(200).json({ message: 'Bet placed successfully', betId });
        } else {
            console.error('Failed to insert bet into database');
            res.status(500).json({ error: 'Failed to place bet' });
        }
    } catch (error) {
        console.error('Error placing bet:', error);
        res.status(500).json({ error: 'Failed to place bet' });
    }
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
