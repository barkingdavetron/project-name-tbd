const express = require('express');
const session = require('express-session');
const { Pool } = require('pg');
const path = require('path');
const crypto = require('crypto');

const app = express();

// Configure PostgreSQL connection
const pool = new Pool({
  user: 'admin',
  host: 'db',
  database: 'users',
  password: 'admin',
  port: 5432,
});

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Generate a secure random secret key
const secretKey = crypto.randomBytes(32).toString('hex');

// Configure session middleware
app.use(session({
  secret: secretKey,
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// Middleware to log session data
app.use((req, res, next) => {
  console.log('Session:', req.session);
  next();
});

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to protect routes
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    return next();
  } else {
    res.redirect('/login');
  }
}

// Render registration form
app.get('/', (req, res) => {
  res.render('index');
});

// Handle registration
app.post('/register', async (req, res) => {
  const { firstName, lastName, email, password, username } = req.body;
  try {
    const query = 'INSERT INTO users (first_name, last_name, email, password, username) VALUES ($1, $2, $3, $4, $5)';
    const values = [firstName, lastName, email, password, username];
    await pool.query(query, values);
    res.redirect('/login');
  } catch (err) {
    console.error('Error inserting user data:', err);
    res.status(500).send('Error inserting user data');
  }
});

// Render login form
app.get('/login', (req, res) => {
  res.render('login');
});

// Handle login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const query = 'SELECT * FROM users WHERE email = $1 AND password = $2';
    const values = [email, password];
    const result = await pool.query(query, values);

    if (result.rows.length > 0) {
      // Save user info in session
      req.session.user = {
        id: result.rows[0].id,
        email: result.rows[0].email,
        username: result.rows[0].username
      };
      res.redirect('/dashboard');
    } else {
      res.status(401).send('Invalid email or password');
    }
  } catch (err) {
    console.error('Error logging in:', err);
    res.status(500).send('Error logging in');
  }
});

// Protected route (dashboard)
app.get('/dashboard', isAuthenticated, (req, res) => {
  res.render('dashboard', { username: req.session.user.username });
});

// Betting page
app.get('/bets', isAuthenticated, (req, res) => {
  res.render('bets', { username: req.session.user.username });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
