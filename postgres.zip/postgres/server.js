// Import necessary modules
const express = require('express'); // Web framework for Node.js
const session = require('express-session'); // Session management
const { Pool } = require('pg'); // PostgreSQL client for Node.js
const path = require('path'); // Path utility for working with file and directory paths
const crypto = require('crypto'); // Cryptographic functions
const bcrypt = require('bcryptjs'); // Password hashing
const fetch = require('node-fetch'); // Fetch API for making HTTP requests
const cron = require('node-cron'); // Task scheduling
const puppeteer = require('puppeteer'); // Puppeteer for web scraping

// Create an instance of the Express application
const app = express(); // Initialize Express application

// Middleware to parse JSON bodies
app.use(express.json()); // Middleware to handle JSON requests

// Configure PostgreSQL connection
const pool = new Pool({
    user: 'admin', // Database user
    host: 'db', // Database host
    database: 'users', // Database name
    password: 'admin', // Database password
    port: 5432, // Database port
});

// Middleware to parse URL-encoded form data
app.use(express.urlencoded({ extended: true })); // Middleware to handle URL-encoded requests

// Generate a secure random secret key for session encryption
const secretKey = crypto.randomBytes(32).toString('hex'); // Generate a 32-byte random string for the session secret

// Configure session middleware
app.use(session({
    secret: secretKey, // Secret key for session encryption
    resave: false, // Do not save session if unmodified
    saveUninitialized: true, // Save uninitialized sessions
    cookie: { secure: false } // Set to true if using HTTPS
}));

// Middleware to log session data for debugging
app.use((req, res, next) => {
    console.log('Session:', req.session); // Log session data to the console
    next(); // Pass control to the next handler
});

// Set EJS as the view engine for rendering templates
app.set('view engine', 'ejs'); // Set the view engine to EJS

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Middleware to protect routes that require authentication
function isAuthenticated(req, res, next) {
    if (req.session.user) { // Check if user is authenticated
        return next(); // User is authenticated, proceed to the route
    } else {
        res.redirect('/login'); // User is not authenticated, redirect to login
    }
}

// Render the registration form
app.get('/', (req, res) => {
    res.render('index'); // Render the index page
});

// Handle user registration
app.post('/register', async (req, res) => {
    const { firstName, lastName, email, password, username } = req.body; // Destructure form data
    try {
        // Check if email already exists
        const checkEmailQuery = 'SELECT email FROM users WHERE email = $1';
        const emailResult = await pool.query(checkEmailQuery, [email]);

        if (emailResult.rows.length > 0) {
            return res.status(400).send('Email already exists'); // Email already exists
        }

        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password
        const query = 'INSERT INTO users (first_name, last_name, email, password, username, balance, experience_points, level) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)';
        const values = [firstName, lastName, email, hashedPassword, username, 0, 0, 1]; // User data values
        await pool.query(query, values); // Insert user into database
        res.redirect('/login'); // Redirect to login page after successful registration
    } catch (err) {
        console.error('Error inserting user data:', err); // Log error
        res.status(500).send('Error inserting user data'); // Handle errors
    }
});

// Render the login form
app.get('/login', (req, res) => {
    res.render('login'); // Render the login page
});

// Handle user login
app.post('/login', async (req, res) => {
    const { email, password } = req.body; // Destructure form data
    try {
        const query = 'SELECT * FROM users WHERE email = $1';
        const values = [email];
        const result = await pool.query(query, values); // Query user by email

        if (result.rows.length > 0) {
            const user = result.rows[0];
            const isPasswordValid = await bcrypt.compare(password, user.password); // Compare hashed password

            if (isPasswordValid) {
                // Save user info in session
                req.session.user = {
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    balance: user.balance,
                    experience_points: user.experience_points,
                    level: user.level
                };
                res.redirect('/dashboard'); // Redirect to dashboard on successful login
            } else {
                res.status(401).send('Invalid email or password'); // Handle invalid password
            }
        } else {
            res.status(401).send('Invalid email or password'); // Handle user not found
        }
    } catch (err) {
        console.error('Error logging in:', err); // Log error
        res.status(500).send('Error logging in'); // Handle errors
    }
});

// Protected route: Dashboard
app.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { 
        username: req.session.user.username, 
        balance: req.session.user.balance, 
        experience_points: req.session.user.experience_points, 
        level: req.session.user.level 
    }); // Render dashboard page with user data
});

// Additional routes
app.get('/sports', isAuthenticated, (req, res) => {
    res.render('sports', { username: req.session.user.username }); // Render sports page
});

app.get('/f1', isAuthenticated, (req, res) => {
    res.render('f1', { username: req.session.user.username }); // Render F1 page
});

app.get('/mma', isAuthenticated, (req, res) => {
    res.render('mma', { username: req.session.user.username }); // Render MMA page
});

// Betting page
app.get('/bets', isAuthenticated, (req, res) => {
    res.render('bets', { username: req.session.user.username }); // Render bets page
});

// Account page
app.get('/account', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const betsQuery = 'SELECT * FROM bets WHERE user_id = $1';
        const betsResult = await pool.query(betsQuery, [userId]); // Query user bets
        const bets = betsResult.rows;

        const userQuery = 'SELECT balance, experience_points, level FROM users WHERE id = $1';
        const userResult = await pool.query(userQuery, [userId]); // Query user data
        const balance = userResult.rows[0].balance;
        const experience_points = userResult.rows[0].experience_points;
        const level = userResult.rows[0].level;

        res.render('account', { 
            username: req.session.user.username, 
            balance, experience_points, level, bets 
        }); // Render account page with user data
    } catch (error) {
        console.error('Error fetching account data:', error); // Log error
        res.status(500).send('Error fetching account data'); // Handle errors
    }
});

// Update user balance by adding funds
app.post('/addFunds', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const updateBalanceQuery = 'UPDATE users SET balance = balance + 100 WHERE id = $1';
        await pool.query(updateBalanceQuery, [userId]); // Add funds to user's balance

        // Update session balance
        req.session.user.balance += 100;

        res.status(200).json({ message: 'Funds added successfully', newBalance: req.session.user.balance }); // Send success response
    } catch (error) {
        console.error('Error adding funds:', error); // Log error
        res.status(500).send('Error adding funds'); // Handle errors
    }
});

// Endpoint to fetch events from Pinnacle API
app.get('/fetchEvents', async (req, res) => {
    try {
        const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
        const options = {
            headers: {
                'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a',
                'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
            }
        };

        const response = await fetch(url, options); // Fetch data from Pinnacle API
        const data = await response.json(); // Parse JSON response
        res.json(data); // Send JSON response
    } catch (error) {
        console.error('Error fetching events:', error); // Log error
        res.status(500).json({ error: 'Failed to fetch events' }); // Handle errors
    }
});

// Endpoint to place a bet
app.post('/placeBet', async (req, res) => {
    const { event, outcome, amount, payout, commence_time } = req.body; // Destructure form data
    const userId = req.session.user.id;

    try {
        // Check if user has sufficient balance
        const userQuery = 'SELECT balance, experience_points, level FROM users WHERE id = $1';
        const userResult = await pool.query(userQuery, [userId]);
        const balance = userResult.rows[0].balance;
        const currentXP = userResult.rows[0].experience_points;
        const currentLevel = userResult.rows[0].level;

        if (balance < amount) {
            return res.status(400).json({ error: 'Insufficient balance' }); // Handle insufficient balance
        }

        // Deduct bet amount from user's balance
        const deductBalanceQuery = 'UPDATE users SET balance = balance - $1 WHERE id = $2';
        await pool.query(deductBalanceQuery, [amount, userId]);

        // Calculate new XP
        const xpGained = amount * 5;
        const newXP = currentXP + xpGained;

        // Calculate new level
        const newLevel = Math.floor(newXP / 200) + 1;

        // Update user's XP and level
        const updateXPQuery = 'UPDATE users SET experience_points = $1, level = $2 WHERE id = $3';
        await pool.query(updateXPQuery, [newXP, newLevel, userId]);

        // Update session data
        req.session.user.experience_points = newXP;
        req.session.user.level = newLevel;

        // Extract and format commence_time to date (YYYY-MM-DD)
        const commenceDate = commence_time.split('T')[0]; // Extract date part only

        // Insert bet into database
        const query = 'INSERT INTO bets (user_id, event, outcome, amount, payout, commence_time, processed) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id';
        const values = [userId, event, outcome, amount, payout, commenceDate, false];
        const result = await pool.query(query, values);

        if (result.rowCount > 0) {
            const betId = result.rows[0].id;
            console.log(`Bet placed successfully with ID ${betId}`);
            res.status(200).json({ message: 'Bet placed successfully' }); // Confirm bet placement
        } else {
            console.error('Failed to insert bet into database'); // Log error
            res.status(500).json({ error: 'Failed to place bet' }); // Handle errors
        }
    } catch (error) {
        console.error('Error placing bet:', error); // Log error
        res.status(500).json({ error: 'Failed to place bet' }); // Handle errors
    }
});

// Function to scrape event results from Goal.com using Puppeteer
async function scrapeEventResults(date) {
    const url = `https://www.goal.com/en/results/${date}`;

    try {
        // Launch Puppeteer with the new headless mode and necessary arguments
        const browser = await puppeteer.launch({
            headless: 'new', // Use 'new' for the latest headless mode
            args: ['--no-sandbox', '--disable-setuid-sandbox'] // Necessary for Docker or restricted environments
        });
        const page = await browser.newPage();
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Wait for the page to load
        await page.waitForSelector('body'); // Adjust selector if needed

        // Extract event URLs and names from the page
        const eventData = await page.evaluate(() => {
            const links = Array.from(document.querySelectorAll('a')); // Adjust selector if needed
            return links
                .filter(link => link.href.includes('match')) // Filter for match URLs
                .map(link => ({
                    url: link.href,
                    name: link.textContent.replace(/\s+/g, ' ').trim() // Improve readability by replacing whitespace with a single space
                }));
        });

        await browser.close();
        return eventData;
    } catch (error) {
        console.error('Error scraping event results:', error); // Log error
        return []; // Return empty array on error
    }
}

// Function to scrape match result from a specific event URL
async function scrapeMatchResult(url) {
    try {
        const browser = await puppeteer.launch({
            headless: 'new', // Use 'new' for the latest headless mode
            args: ['--no-sandbox', '--disable-setuid-sandbox'] // Necessary for Docker or restricted environments
        });
        const page = await browser.newPage();
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Wait for the page to load and display the match result
        await page.waitForSelector('.match-info', { timeout: 5000 }); // Adjust selector if needed

        // Extract match result data
        const matchResult = await page.evaluate(() => {
            const homeTeam = document.querySelector('.home-team').textContent.trim();
            const awayTeam = document.querySelector('.away-team').textContent.trim();
            const score = document.querySelector('.score').textContent.trim();
            const [homeScore, awayScore] = score.split('-').map(Number);
            return { homeTeam, awayTeam, homeScore, awayScore };
        });

        await browser.close();
        return matchResult;
    } catch (error) {
        console.error('Error scraping match result:', error); // Log error
        return null;
    }
}

// Function to process payouts for bets
async function processPayouts() {
    try {
        console.log('Starting payout processing...');
        
        // Query for unprocessed bets
        const selectBetsQuery = 'SELECT * FROM bets WHERE processed = false';
        const betsResult = await pool.query(selectBetsQuery);
        const bets = betsResult.rows;

        console.log('Unprocessed bets:', bets);

        for (const bet of bets) {
            const { id, user_id, event, outcome, payout, commence_time } = bet;

            console.log(`Processing bet ID ${id} for event ${event}`);

            // Scrape the results for the event
            const eventResults = await scrapeEventResults(commence_time);

            // Normalize event name
            const normalizedEvent = event.replace(/\s+/g, '').trim();

            // Find the matching event URL
            const eventUrl = eventResults.find(result => result.name.replace(/\s+/g, '').trim().includes(normalizedEvent));

            if (eventUrl) {
                console.log(`Scraped URL for event ${event}: ${eventUrl.url}`);

                // Scrape the match result from the event URL
                const matchResult = await scrapeMatchResult(eventUrl.url);

                if (matchResult) { // Check if match result is available
                    const { homeTeam, awayTeam, homeScore, awayScore } = matchResult; // Destructure match result data

                    let isWin = false; // Initialize win status to false
                    if (outcome === 'Draw' && homeScore === awayScore) { // Check if outcome is a draw and scores are equal
                        isWin = true; // Set win status to true
                    } else if (outcome === homeTeam && homeScore > awayScore) { // Check if outcome is home team win
                        isWin = true; // Set win status to true
                    } else if (outcome === awayTeam && awayScore > homeScore) { // Check if outcome is away team win
                        isWin = true; // Set win status to true
                    }

                    console.log(`Bet ${id} ${isWin ? 'won' : 'lost'}`); // Log bet result

                    if (isWin) { // Check if the bet was won
                        // Update user balance if bet won
                        const updateBalanceQuery = 'UPDATE users SET balance = balance + $1 WHERE id = $2'; 
                        await pool.query(updateBalanceQuery, [payout, user_id]); // Update user balance in database
                    }

                    // Mark the bet as processed
                    const updateBetQuery = 'UPDATE bets SET processed = true, won = $1 WHERE id = $2'; 
                    await pool.query(updateBetQuery, [isWin, id]); // Update bet status in database
                } else {
                    console.log(`No match result found for event ${event}`); // Log no match result found
                }
            } else {
                console.log(`No matching event found for bet ID ${id}`); // Log no matching event found
            }
        }
        console.log('Payouts processed successfully'); // Log successful payout processing
    } catch (error) {
        console.error('Error processing payouts:', error); // Log error in processing payouts
    }
}


// Schedule the payout processing to run every minute
cron.schedule('* * * * *', processPayouts);

// Start the Express server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`); // Log server start
});
