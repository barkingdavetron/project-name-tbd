const axios = require('axios');

const appKey = 'MubK6WmvNuZ5pUES';
const sessionToken = 'BF0E3twmmAemPXtwnEaWn7mHlkCytIaNCC5gzHjBu00=';

const betfairAPI = axios.create({
    baseURL: 'https://api.betfair.com/exchange/betting/rest/v1.0/',
    headers: {
        'X-Application': appKey,
        'X-Authentication': sessionToken,
        'Content-Type': 'application/json',
    },
});

async function fetchBetfairEvents() {
    const body = JSON.stringify({
        filter: {
            eventTypeIds: ['1'], // Football
            marketTypeCodes: ['MATCH_ODDS'],
        },
        maxResults: '10',
        marketProjection: ['COMPETITION', 'EVENT', 'MARKET_START_TIME', 'RUNNER_DESCRIPTION'],
    });

    try {
        const response = await betfairAPI.post('listMarketCatalogue/', body);
        return response.data;
    } catch (error) {
        console.error('Error fetching Betfair events:', error);
        return [];
    }
}

async function fetchBetfairEventResults(eventId) {
    const body = JSON.stringify({
        marketIds: [eventId],
    });

    try {
        const response = await betfairAPI.post('listMarketBook/', body);
        return response.data;
    } catch (error) {
        console.error('Error fetching Betfair event results:', error);
        return [];
    }
}

module.exports = { fetchBetfairEvents, fetchBetfairEventResults };
