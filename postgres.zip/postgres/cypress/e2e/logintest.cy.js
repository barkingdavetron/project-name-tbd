describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://localhost:3000/login')
    cy.get('input#email').type('johndoe@gmail.com')
    cy.get('input#password').type('password')
    cy.get('form').submit()
    
        // Navigate to betting page
        cy.get('a[href="/bets"]').click(); // Assuming there's a link to the bets page

        // Select the first event and outcome
        cy.get('#event-select').select(0); // Select the first event
        cy.get('#outcome-select').select(0); // Select the first outcome

        // Enter bet amount
        cy.get('input[name="bet-amount"]').clear().type('1');

        // Place the bet
        cy.get('#place-bet-button').click();

        // Verify bet placement
        cy.contains('Bet placed successfully').should('be.visible');
  })
})