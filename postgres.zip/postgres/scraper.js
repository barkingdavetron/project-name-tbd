const axios = require('axios');
const cheerio = require('cheerio');

// Function to fetch match results
async function fetchMatchResults(matchName) {
    try {
        // Replace the URL with the actual URL of the website you want to scrape
        const response = await axios.get('https://example.com/match-results');
        const html = response.data;
        const $ = cheerio.load(html);

        let result;

        // Example of how to scrape the match result
        $('table.match-results tr').each((index, element) => {
            const match = $(element).find('td.match-name').text().trim();
            const matchResult = $(element).find('td.match-result').text().trim();

            if (match.includes(matchName)) {
                result = matchResult;
                return false; // Exit the loop once the match is found
            }
        });

        return result ? { matchName, result } : { matchName, result: 'Not found' };
    } catch (error) {
        console.error(`Error fetching match results: ${error.message}`);
        return { matchName, result: 'Error fetching results' };
    }
}

module.exports = fetchMatchResults;
