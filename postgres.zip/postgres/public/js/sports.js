// Add an event listener to the document to execute a function when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize quiz variables
    let questionCount = 0; // Current question index
    let questionNumb = 1; // Question number display
    let userScore = 0; // User's current score
    let userXP = 0; // User's experience points
    let userLevel = 1; // User's level

    // Get references to various DOM elements
    const nextBtn = document.querySelector('.next-btn');
    const startBtn = document.querySelector('.start-btn');
    const popupInfo = document.querySelector('.popup-info');
    const exitBtn = document.querySelector('.exit-btn');
    const continueBtn = document.querySelector('.continue-btn');
    const quizSection = document.querySelector('.quiz-section');
    const quizBox = document.querySelector('.quiz-box');
    const resultBox = document.querySelector('.result-box');
    const tryAgainBtn = document.querySelector('.tryAgain-btn');
    const goHomeBtn = document.querySelector('.goHome-btn');
    const optionList = document.querySelector('.option-list');

    // Event listeners for buttons
    startBtn.onclick = () => popupInfo.classList.add('active'); // Show popup info on start button click
    exitBtn.onclick = () => popupInfo.classList.remove('active'); // Hide popup info on exit button click
    continueBtn.onclick = startQuiz; // Start the quiz on continue button click
    tryAgainBtn.onclick = resetQuiz; // Reset the quiz on try again button click
    goHomeBtn.onclick = resetQuiz; // Reset the quiz on go home button click

    // Move to the next question or show the result box if it's the last question
    nextBtn.onclick = () => {
        if (questionCount < footballquestions.length - 1) {
            questionCount++;
            questionNumb++;
            showQuestions(questionCount); // Show the next question
            questionCounter(questionNumb); // Update question counter
            nextBtn.classList.remove('active'); // Hide next button
        } else {
            userXP += userScore; // Add user score to XP
            updateExperienceBar(); // Update experience bar
            showResultBox(); // Show the result box
        }
    };

    // Function to start the quiz
    function startQuiz() {
        quizSection.classList.add('active'); // Show quiz section
        popupInfo.classList.remove('active'); // Hide popup info
        quizBox.classList.add('active'); // Show quiz box
        showQuestions(0); // Show the first question
        questionCounter(1); // Update question counter
        headerScore(0); // Update header score
    }

    // Function to reset the quiz
    function resetQuiz() {
        quizBox.classList.add('active'); // Show quiz box
        nextBtn.classList.remove('active'); // Hide next button
        resultBox.classList.remove('active'); // Hide result box
        questionCount = 0; // Reset question index
        questionNumb = 1; // Reset question number display
        userScore = 0; // Reset user score
        showQuestions(questionCount); // Show the first question
        questionCounter(questionNumb); // Update question counter
        headerScore(); // Update header score
    }

    // Function to show questions
    function showQuestions(index) {
        const questionText = document.querySelector('.question-text');
        if (questionText) {
            questionText.textContent = `${footballquestions[index].numb}. ${footballquestions[index].question}`;
            let optionTag = footballquestions[index].options.map(option => `<div class="option"><span>${option}</span></div>`).join('');
            optionList.innerHTML = optionTag; // Display options
            const options = document.querySelectorAll('.option');
            options.forEach(option => option.addEventListener('click', () => optionSelected(option))); // Add click event listener to options
        }
    }

    // Function to handle option selection
    function optionSelected(answer) {
        let userAnswer = answer.textContent;
        let correctAnswer = footballquestions[questionCount].answer;
        let allOptions = optionList.children.length;
        if (userAnswer == correctAnswer) {
            answer.classList.add('correct'); // Mark answer as correct
            userScore += 1; // Increase user score
            headerScore(); // Update header score
        } else {
            answer.classList.add('incorrect'); // Mark answer as incorrect
            for (let i = 0; i < allOptions; i++) {
                if (optionList.children[i].textContent == correctAnswer) {
                    optionList.children[i].setAttribute('class', 'option correct'); // Mark correct option
                }
            }
        }
        for (let i = 0; i < allOptions; i++) {
            optionList.children[i].classList.add('disabled'); // Disable all options
        }
        nextBtn.classList.add('active'); // Show next button
    }

    // Function to update question counter
    function questionCounter(index) {
        const questionTotal = document.querySelector('.question-total');
        if (questionTotal) {
            questionTotal.textContent = `${index} of ${footballquestions.length} Questions`;
        }
    }

    // Function to update header score
    function headerScore() {
        const headerScoreText = document.querySelector('.header-score');
        if (headerScoreText) {
            headerScoreText.textContent = `Score: ${userScore} / ${footballquestions.length}`;
        }
    }

    // Function to show result box
    function showResultBox() {
        if (quizBox && resultBox) {
            quizBox.classList.remove('active'); // Hide quiz box
            resultBox.classList.add('active'); // Show result box
            const scoreText = document.querySelector('.score-text');
            if (scoreText) {
                scoreText.textContent = `Your Score ${userScore} out of ${footballquestions.length}`;
            }
            updateCircularProgress(); // Update circular progress
        }
    }

    // Function to update circular progress
    function updateCircularProgress() {
        const circularProgress = document.querySelector('.circular-progress');
        const progressValue = document.querySelector('.progress-value');
        let progressStartValue = 0;
        let progressEndValue = Math.min((userScore / footballquestions.length) * 100, 100); // Calculate progress percentage
        let speed = 20; // Speed of progress update
        let progress = setInterval(() => {
            progressStartValue++;
            if (progressStartValue > progressEndValue) {
                progressStartValue = progressEndValue;
                clearInterval(progress); // Stop the interval when reaching the end value
            }
            if (progressValue) {
                progressValue.textContent = `${progressStartValue}%`;
            }
            if (circularProgress) {
                circularProgress.style.background = `conic-gradient(#ff9900 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
            }
        }, speed);
    }

    // Function to update experience bar
    function updateExperienceBar() {
        const experienceBar = document.getElementById('experience-bar');
        const experienceText = document.getElementById('experience-text');
        if (experienceBar && experienceText) {
            experienceBar.style.width = `${(userXP % 10) * 10}%`;
            experienceText.textContent = `${userXP % 10}/10 XP`;
            if (userXP >= 10) {
                userLevel += Math.floor(userXP / 10);
                userXP = userXP % 10;
                alert(`Congratulations! You've reached Level ${userLevel}`);
                updateLevelDisplay(); // Update level display
            }
        } else {
            console.error('Experience bar or Level element not found in the DOM.');
        }
    }

    // Function to update level display
    function updateLevelDisplay() {
        const userLevelElement = document.querySelector('.user-Level');
        if (userLevelElement) {
            userLevelElement.textContent = `Level: ${userLevel}`;
        }
    }

    // Function to fetch user data from the server
    function fetchUserData() {
        fetch('/userData')
            .then(response => response.json())
            .then(data => {
                if (data.experience_points !== undefined && data.Level !== undefined) {
                    userXP = data.experience_points;
                    userLevel = data.Level;
                    updateExperienceBar(); // Update experience bar with fetched data
                }
            })
            .catch(error => console.error('Error fetching user data:', error));
    }

    fetchUserData(); // Fetch user data when the page loads
});
