// Add an event listener to the document to execute a function when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    let questionCount = 0; // Initialize question count
    let questionNumb = 1; // Initialize question number
    let userScore = 0; // Initialize user score
    let userXP = 0; // Initialize user experience points
    let userLevel = 1; // Initialize user level

    // Get references to various DOM elements
    const nextBtn = document.querySelector('.next-btn');
    const startBtn = document.querySelector('.start-btn');
    const popupInfo = document.querySelector('.popup-info');
    const exitBtn = document.querySelector('.exit-btn');
    const continueBtn = document.querySelector('.continue-btn');
    const quizSection = document.querySelector('.quiz-section');
    const quizBox = document.querySelector('.quiz-box');
    const resultBox = document.querySelector('.result-box');
    const tryAgainBtn = document.querySelector('.tryAgain-btn');
    const goHomeBtn = document.querySelector('.goHome-btn');

    // Show the popup information when the start button is clicked
    startBtn.onclick = () => {
        popupInfo.classList.add('active');
    };
    
    // Hide the popup information when the exit button is clicked
    exitBtn.onclick = () => {
        popupInfo.classList.remove('active');
    };
    
    // Start the quiz when the continue button is clicked
    continueBtn.onclick = () => {
        quizSection.classList.add('active');
        popupInfo.classList.remove('active');
        quizBox.classList.add('active');
        showQuestions(0);
        questionCounter(1);
        headerScore(0);
    };
    
    // Reset the quiz when the try again button is clicked
    tryAgainBtn.onclick = () => {
        quizBox.classList.add('active');
        nextBtn.classList.remove('active');
        resultBox.classList.remove('active');
        questionCount = 0;
        questionNumb = 1;
        userScore = 0;
        showQuestions(questionCount);
        questionCounter(questionNumb);
        headerScore();
    };
    
    // Go back to the home screen when the go home button is clicked
    goHomeBtn.onclick = () => {
        quizSection.classList.remove('active');
        nextBtn.classList.remove('active');
        resultBox.classList.remove('active');
        questionCount = 0;
        questionNumb = 1;
        userScore = 0;
        showQuestions(questionCount);
        questionCounter(questionNumb);
        headerScore();
    };
    
    // Move to the next question when the next button is clicked
    nextBtn.onclick = () => {
        if (questionCount < f1questions.length - 1) {
            questionCount++;
            showQuestions(questionCount);
            questionNumb++;
            questionCounter(questionNumb);
            nextBtn.classList.remove('active');
        } else {
            userXP += userScore; // Add user score to XP
            updateExperienceBar();
            showResultBox();
        }
    };

    // Get reference to the option list
    const optionList = document.querySelector('.option-list');

    // Function to display questions
    function showQuestions(index) {
        const questionText = document.querySelector('.question-text');
        if (questionText) {
            questionText.textContent = `${f1questions[index].numb}. ${f1questions[index].question}`;

            let optionTag = `<div class="option"><span>${f1questions[index].options[0]}</span></div>
            <div class="option"><span>${f1questions[index].options[1]}</span></div>
            <div class="option"><span>${f1questions[index].options[2]}</span></div>
            <div class="option"><span>${f1questions[index].options[3]}</span></div>`;

            optionList.innerHTML = optionTag;

            const option = document.querySelectorAll('.option');
            for (let i = 0; i < option.length; i++) {
                option[i].setAttribute('onclick', 'optionSelected(this)');
            }
        }
    }

    // Function to handle option selection
    window.optionSelected = function(answer) {
        let userAnswer = answer.textContent;
        let correctAnswer = f1questions[questionCount].answer;
        let allOptions = optionList.children.length;

        if (userAnswer == correctAnswer) {
            answer.classList.add('correct');
            userScore += 1;
            headerScore();
        } else {
            answer.classList.add('incorrect');

            for (let i = 0; i < allOptions; i++) {
                if (optionList.children[i].textContent == correctAnswer) {
                    optionList.children[i].setAttribute('class', 'option correct');
                }
            }
        }
        for (let i = 0; i < allOptions; i++) {
            optionList.children[i].classList.add('disabled');
        }
        nextBtn.classList.add('active');
    };

    // Function to update question counter
    function questionCounter(index) {
        const questionTotal = document.querySelector('.question-total');
        if (questionTotal) {
            questionTotal.textContent = `${index} of ${f1questions.length} Questions`;
        }
    }

    // Function to update header score
    function headerScore() {
        const headerScoreText = document.querySelector('.header-score');
        if (headerScoreText) {
            headerScoreText.textContent = `Score: ${userScore} / ${f1questions.length}`;
        }
    }

    // Function to show result box
    function showResultBox(){
        const quizBox = document.querySelector('.quiz-box');
        const resultBox = document.querySelector('.result-box');
        if (quizBox && resultBox) {
            quizBox.classList.remove('active');
            resultBox.classList.add('active');
    
            const scoreText = document.querySelector('.score-text');
            if (scoreText) {
                scoreText.textContent = `Your Score ${userScore} out of ${f1questions.length}`;
            }
    
            const circularProgress = document.querySelector('.circular-progress');
            const progressValue = document.querySelector('.progress-value');
            let progressStartValue = 0;
            let progressEndValue = Math.min((userScore / f1questions.length) * 100, 100); // Ensure max is 100%
            let speed = 20; // Speed of progress update
    
            let progress = setInterval(() =>{
                progressStartValue++;
                if (progressStartValue > progressEndValue) {
                    progressStartValue = progressEndValue;
                    clearInterval(progress); // Stop the interval when reaching the end value
                }
    
                if (progressValue) {
                    progressValue.textContent = `${progressStartValue}%`;
                }
                if (circularProgress) {
                    circularProgress.style.background = `conic-gradient(#ff9900 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
                }
            }, speed);
        }
    }
    
    // Function to update level display
    function updateLevelDisplay() {
        const userLevelElement = document.querySelector('.user-Level');
        if (userLevelElement) {
            userLevelElement.textContent = `Level: ${userLevel}`;
        }
    }

    // Function to update experience bar
    function updateExperienceBar() {
        const experienceBar = document.getElementById('experience-bar');
        const experienceText = document.getElementById('experience-text');
        if (experienceBar && experienceText) {
            experienceBar.style.width = `${(userXP % 10) * 10}%`;
            experienceText.textContent = `${userXP % 10}/10 XP`;

            if (userXP >= 10) {
                userLevel += Math.floor(userXP / 10);
                userXP = userXP % 10;
                alert(`Congratulations! You've reached Level ${userLevel}`);
                updateLevelDisplay();  
            }
        }
    }

    // Fetch user data when the page loads
    fetch('/userData')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const experienceProgress = document.querySelector('.experience-progress');
            if (experienceProgress) {
                experienceProgress.style.width = `${data.experience_points * 10}%`;
            }

            const experienceText = document.querySelector('.experience-text');
            if (experienceText) {
                experienceText.textContent = `Level: ${data.Level} (XP: ${data.experience_points}/10)`;
            }
        })
        .catch(error => {
            console.error('Error fetching user data:', error);
        });
});
