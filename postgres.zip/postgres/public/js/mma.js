document.addEventListener('DOMContentLoaded', () => {
    let questionCount = 0;
    let questionNumb = 1;
    let userScore = 0;
    let userXP = 0;
    let userLevel = 1;
    const nextBtn = document.querySelector('.next-btn');
    const startBtn = document.querySelector('.start-btn');
    const popupInfo = document.querySelector('.popup-info');
    const exitBtn = document.querySelector('.exit-btn');
    const continueBtn = document.querySelector('.continue-btn');
    const quizSection = document.querySelector('.quiz-section');
    const quizBox = document.querySelector('.quiz-box');
    const resultBox = document.querySelector('.result-box');
    const tryAgainBtn = document.querySelector('.tryAgain-btn');
    const goHomeBtn = document.querySelector('.goHome-btn');

    startBtn.onclick = () => {
        popupInfo.classList.add('active');
    }
    
    exitBtn.onclick = () => {
        popupInfo.classList.remove('active');
    }
    
    continueBtn.onclick = () => {
        quizSection.classList.add('active')
        popupInfo.classList.remove('active');
        quizBox.classList.add('active');
    
        showQuestions(0);
        questionCounter(1);
        headerScore(0);
    }
    
     tryAgainBtn.onclick = () => {
        quizBox.classList.add('active');
        nextBtn.classList.remove('active');
        resultBox.classList.remove('active');
    
        questionCount = 0;
        questionNumb = 1;
        userScore = 0;
        showQuestions(questionCount);
        questionCounter(questionNumb);
    
        headerScore();
    }
    
    goHomeBtn.onclick = () => {
        quizSection.classList.remove('active');
        nextBtn.classList.remove('active');
        resultBox.classList.remove('active');
    
        questionCount = 0;
        questionNumb = 1;
        userScore = 0;
        showQuestions(questionCount);
        questionCounter(questionNumb);
    
        headerScore();
    }
    

    nextBtn.onclick = () => {
        if (questionCount < mmaquestions.length - 1) {
            questionCount++;
            showQuestions(questionCount);
            questionNumb++;
            questionCounter(questionNumb);
            nextBtn.classList.remove('active');
        } else {
            userXP += userScore; // Add user score to XP
            updateExperienceBar();
            showResultBox();
        }
    };

 

    const optionList = document.querySelector('.option-list');

    function showQuestions(index) {
        const questionText = document.querySelector('.question-text');
        if (questionText) {
            questionText.textContent = `${mmaquestions[index].numb}. ${mmaquestions[index].question}`;

            let optionTag = `<div class="option"><span>${mmaquestions[index].options[0]}</span></div>
            <div class="option"><span>${mmaquestions[index].options[1]}</span></div>
            <div class="option"><span>${mmaquestions[index].options[2]}</span></div>
            <div class="option"><span>${mmaquestions[index].options[3]}</span></div>`;

            optionList.innerHTML = optionTag;

            const option = document.querySelectorAll('.option');
            for (let i = 0; i < option.length; i++) {
                option[i].setAttribute('onclick', 'optionSelected(this)');
            }
        }
    }

    window.optionSelected = function(answer) {
        let userAnswer = answer.textContent;
        let correctAnswer = mmaquestions[questionCount].answer;
        let allOptions = optionList.children.length;

        if (userAnswer == correctAnswer) {
            answer.classList.add('correct');
            userScore += 1;
            headerScore();
        } else {
            answer.classList.add('incorrect');

            for (let i = 0; i < allOptions; i++) {
                if (optionList.children[i].textContent == correctAnswer) {
                    optionList.children[i].setAttribute('class', 'option correct');
                }
            }
        }
        for (let i = 0; i < allOptions; i++) {
            optionList.children[i].classList.add('disabled');
        }
        nextBtn.classList.add('active');
    };

    function questionCounter(index) {
        const questionTotal = document.querySelector('.question-total');
        if (questionTotal) {
            questionTotal.textContent = `${index} of ${mmaquestions.length} Questions`;
        }
    }

    function headerScore() {
        const headerScoreText = document.querySelector('.header-score');
        if (headerScoreText) {
            headerScoreText.textContent = `Score: ${userScore} / ${mmaquestions.length}`;
        }
    }

    function showResultBox(){
        const quizBox = document.querySelector('.quiz-box');
        const resultBox = document.querySelector('.result-box');
        if (quizBox && resultBox) {
            quizBox.classList.remove('active');
            resultBox.classList.add('active');
    
            const scoreText = document.querySelector('.score-text');
            if (scoreText) {
                scoreText.textContent = `Your Score ${userScore} out of ${mmaquestions.length}`;
            }
    
            const circularProgress = document.querySelector('.circular-progress');
            const progressValue = document.querySelector('.progress-value');
            let progressStartValue = 0;
            let progressEndValue = Math.min((userScore / mmaquestions.length) * 100, 100); // Ensure max is 100%
            let speed = 20; // Speed of progress update
    
            let progress = setInterval(() =>{
                progressStartValue++;
                if (progressStartValue > progressEndValue) {
                    progressStartValue = progressEndValue;
                    clearInterval(progress); // Stop the interval when reaching the end value
                }
    
                if (progressValue) {
                    progressValue.textContent = `${progressStartValue}%`;
                }
                if (circularProgress) {
                    circularProgress.style.background = `conic-gradient(#ff9900 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
                }
            }, speed);
        }
    }
    

    function updateLevelDisplay() {
        const userLevelElement = document.querySelector('.user-Level');
        if (userLevelElement) {
            userLevelElement.textContent = `Level: ${userLevel}`;
        }
    }

    function updateExperienceBar() {
        const experienceBar = document.getElementById('experience-bar');
        const experienceText = document.getElementById('experience-text');
        if (experienceBar && experienceText) {
            experienceBar.style.width = `${(userXP % 10) * 10}%`;
            experienceText.textContent = `${userXP % 10}/10 XP`;

            if (userXP >= 10) {
                userLevel += Math.floor(userXP / 10);
                userXP = userXP % 10;
                alert(`Congratulations! You've reached Level ${userLevel}`);
                updateLevelDisplay();  
            }
        }
    }

    // Fetch user data when the page loads
    fetch('/userData')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const experienceProgress = document.querySelector('.experience-progress');
            if (experienceProgress) {
                experienceProgress.style.width = `${data.experience_points * 10}%`;
            }

            const experienceText = document.querySelector('.experience-text');
            if (experienceText) {
                experienceText.textContent = `Level: ${data.Level} (XP: ${data.experience_points}/10)`;
            }
        })
        .catch(error => {
            console.error('Error fetching user data:', error);
        });
});
