const url = 'https://betsmart-sports-betting-api.p.rapidapi.com/BettingGetOdds?sport=upcoming&regions=au%2Ceu%2Cuk%2Cus%2Cus2';
const options = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': '3e2c571e03msh65252003b5e34e7p1d978fjsn576b1362083a',
        'X-RapidAPI-Host': 'betsmart-sports-betting-api.p.rapidapi.com'
    }
};

let events = [];
let betHistory = [];

async function fetchData() {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const result = await response.json();
        console.log(result);
        events = result;
        displayEvents(events);
        document.getElementById('betting-form').style.display = 'block';
    } catch (error) {
        console.error('Error fetching data:', error);
        document.getElementById('results').innerHTML = `<p>Error: ${error.message}</p>`;
    }
}

function displayEvents(events) {
    const eventSelect = document.getElementById('event-select');
    eventSelect.innerHTML = '';
    events.forEach((event, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = `${event.home_team} vs ${event.away_team}`;
        eventSelect.appendChild(option);
    });
    updateOutcomes();
}

function updateOutcomes() {
    const eventSelect = document.getElementById('event-select');
    const selectedEventIndex = eventSelect.value;
    const selectedEvent = events[selectedEventIndex];
    const outcomeSelect = document.getElementById('outcome-select');
    outcomeSelect.innerHTML = '';

    if (selectedEvent && selectedEvent.bookmakers && selectedEvent.bookmakers.length > 0) {
        const outcomes = selectedEvent.bookmakers[0].markets[0].outcomes; // Assuming first bookmaker and first market
        outcomes.forEach((outcome, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = `${outcome.name} (Odds: ${outcome.price})`;
            outcomeSelect.appendChild(option);
        });
    }
}
function placeBet() {
    const eventIndex = document.getElementById('event-select').value;
    const outcomeIndex = document.getElementById('outcome-select').value;
    const betAmount = parseFloat(document.getElementById('bet-amount').value);
    const selectedEvent = events[eventIndex];
    const selectedOutcome = selectedEvent.bookmakers[0].markets[0].outcomes[outcomeIndex];
    const potentialPayout = betAmount * selectedOutcome.price;

    const data = {
        event: `${selectedEvent.home_team} vs ${selectedEvent.away_team}`,
        outcome: selectedOutcome.name,
        amount: betAmount,
        payout: potentialPayout
    };

    console.log('Data to send:', data); // Log data to send

    fetch('/placeBet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('Raw response:', response); // Log raw response
        return response.text().then(text => {
            try {
                return JSON.parse(text);
            } catch (error) {
                throw new Error(`Invalid JSON: ${text}`);
            }
        });
    })
    .then(result => {
        console.log(result); // Log response from backend
        if (result.error) {
            throw new Error(result.error);
        }
        // Update betHistory with the new bet
        betHistory.push(data);
        displayBetHistory(); // Update UI with the new bet
    })
    .catch(error => {
        console.error('Error placing bet:', error);
        // Display error message to the user
        document.getElementById('results').innerHTML = `<p>Error: ${error.message}</p>`;
    });
}



function displayBetHistory() {
    const betHistoryDiv = document.getElementById('bet-history');
    const betTableBody = document.getElementById('bet-table').getElementsByTagName('tbody')[0];
    betTableBody.innerHTML = '';

    betHistory.forEach((bet, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${bet.event}</td>
            <td>${bet.outcome}</td>
            <td>$${bet.amount.toFixed(2)}</td>
            <td>$${bet.payout.toFixed(2)}</td>
            <td><button class="delete-button" onclick="deleteBet(${index})">Delete</button></td>
        `;
        betTableBody.appendChild(row);
    });

    betHistoryDiv.style.display = betHistory.length ? 'block' : 'none';
}

document.getElementById('event-select').addEventListener('change', updateOutcomes);

fetchData();
