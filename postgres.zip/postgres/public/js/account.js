//button to add funds
document.getElementById('add-funds-button').addEventListener('click', async function() {
  try {
      // Make a POST request to the '/addFunds' endpoint
      const response = await fetch('/addFunds', {
          method: 'POST', // Specify the request method as POST
          headers: {
              'Content-Type': 'application/json' // Set the content type to JSON
          }
      });
      
      // Parse the response as JSON
      const result = await response.json();
      
      // If the response status is OK (status code 200-299)
      if (response.ok) {
          // Update the balance displayed on the page with the new balance from the response
          document.getElementById('balance').textContent = result.newBalance;
          // Show an alert with a success message
          alert(result.message);
      } else {
          // Show an alert with an error message if the response is not OK
          alert('Error adding funds: ' + result.message);
      }
  } catch (error) {
      // Log any errors that occur during the fetch request or response parsing
      console.error('Error:', error);
  }
});
