document.getElementById('add-funds-button').addEventListener('click', async function() {
    try {
      const response = await fetch('/addFunds', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const result = await response.json();
      if (response.ok) {
        document.getElementById('balance').textContent = result.newBalance;
        alert(result.message);
      } else {
        alert('Error adding funds: ' + result.message);
      }
    } catch (error) {
      console.error('Error:', error);
     
    }
  });